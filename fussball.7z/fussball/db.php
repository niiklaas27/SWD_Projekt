<?php
$servername = "localhost";
$username = "root"; // Ihr MySQL-Benutzername
$password = ""; // Ihr MySQL-Passwort
$dbname = "fussball"; // Ihr Datenbankname

// Verbindung herstellen
$conn = new mysqli($servername, $username, $password, $dbname);

// Überprüfung der Verbindung
if ($conn->connect_error) {
    die("Verbindung fehlgeschlagen: " . $conn->connect_error);
}
?>
