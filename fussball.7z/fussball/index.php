<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fußball App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Willkommen zur Fußball App</h1>
    <nav>
        <ul>
            <li><a href="players.php">Spieler anzeigen</a></li>
            <li><a href="add_player.php">Spieler hinzufügen</a></li>
        </ul>
    </nav>
</body>
</html>
