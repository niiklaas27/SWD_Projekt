<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spieler hinzufügen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Neuen Spieler hinzufügen</h1>
    <form action="add_player.php" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="age">Alter:</label>
        <input type="number" id="age" name="age" required>
        
        <label for="position">Position:</label>
        <input type="text" id="position" name="position" required>
        
        <label for="nationality">Nationalität:</label>
        <select id="nationality" name="nationality" required>
            <option value="">Bitte wählen</option>
            <?php
            include 'db.php';

            // Nationalitäten abrufen und Dropdown füllen
            $sql = "SELECT * FROM Nationalities";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['nationality_id']}'>{$row['name']}</option>";
                }
            } else {
                echo "<option value=''>Keine Nationalitäten gefunden</option>";
            }

            $conn->close();
            ?>
        </select>

        <label for="team_id">Team:</label>
        <select id="team_id" name="team_id" required>
            <option value="">Bitte wählen</option>
            <?php
            include 'db.php';

            // Teams abrufen und Dropdown füllen
            $sql = "SELECT * FROM Teams";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['team_id']}'>{$row['name']} (ID: {$row['team_id']})</option>";
                }
            } else {
                echo "<option value=''>Keine Teams gefunden</option>";
            }

            $conn->close();
            ?>
        </select>

        <label for="goals">Anzahl Tore:</label>
        <input type="number" id="goals" name="goals" value="0" required min="0">
        
        <input type="submit" value="Spieler hinzufügen">
    </form>

    <?php
    include 'db.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $position = $_POST['position'];
        $nationality_id = $_POST['nationality']; // Nationalität abfangen
        $team_id = $_POST['team_id'];
        $goals = $_POST['goals'];

        // Spieler in der Spieler-Tabelle hinzufügen
        $sql = "INSERT INTO Spieler (name, age, position, nationality_id, team_id) VALUES ('$name', $age, '$position', $nationality_id, $team_id)";

        if ($conn->query($sql) === TRUE) {
            // Letzte eingefügte ID abrufen
            $last_id = $conn->insert_id;

            // Tore in der Tore-Tabelle hinzufügen
            for ($i = 0; $i < $goals; $i++) {
                $sql_goals = "INSERT INTO Tore (player_id) VALUES ($last_id)";
                $conn->query($sql_goals);
            }

            echo "<p style='text-align:center; color:green;'>Neuer Spieler erfolgreich hinzugefügt!</p>";
        } else {
            echo "<p style='text-align:center; color:red;'>Fehler: " . $sql . "<br>" . $conn->error . "</p>";
        }

        $conn->close();
    }
    ?>
    <a href="index.php">Zurück zur Startseite</a>
</body>
</html>
