<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spielerliste</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Spielerliste</h1>

    <form method="GET" action="players.php">
        <label for="filter_name">Name:</label>
        <input type="text" id="filter_name" name="filter_name" placeholder="Spielername">
        
        <label for="filter_nationality">Nationalität:</label>
        <input type="text" id="filter_nationality" name="filter_nationality" placeholder="Nationalität">
        
        <label for="filter_team">Team:</label>
        <select id="filter_team" name="filter_team">
            <option value="">Alle Teams</option>
            <?php
            include 'db.php';

            // Teams abrufen und Dropdown füllen
            $sql = "SELECT * FROM Teams";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['team_id']}'>{$row['name']} (ID: {$row['team_id']})</option>";
                }
            } 

            $conn->close();
            ?>
        </select>

        <input type="submit" value="Filtern">
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Alter</th>
                <th>Position</th>
                <th>Nationalität</th>
                <th>Team</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'db.php';

            // Filter-Parameter abrufen
            $filter_name = isset($_GET['filter_name']) ? $_GET['filter_name'] : '';
            $filter_nationality = isset($_GET['filter_nationality']) ? $_GET['filter_nationality'] : '';
            $filter_team = isset($_GET['filter_team']) ? $_GET['filter_team'] : '';

            // SQL-Query mit Filtern
            $sql = "SELECT Spieler.*, Teams.name AS team_name FROM Spieler 
                    LEFT JOIN Teams ON Spieler.team_id = Teams.team_id 
                    WHERE 1=1"; // Base Query

            // Filter anwenden
            if (!empty($filter_name)) {
                $sql .= " AND Spieler.name LIKE '%$filter_name%'";
            }
            if (!empty($filter_nationality)) {
                $sql .= " AND Spieler.nationality LIKE '%$filter_nationality%'";
            }
            if (!empty($filter_team)) {
                $sql .= " AND Spieler.team_id = '$filter_team'";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['player_id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['age']}</td>
                            <td>{$row['position']}</td>
                            <td>{$row['nationality']}</td>
                            <td>{$row['team_name']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>Keine Spieler gefunden.</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>

    <a href="index.php">Zurück zur Startseite</a>
</body>
</html>
